
import root from '../root.js';
import { set_building, set_prerendering } from '__sveltekit/environment';
import { set_assets } from '__sveltekit/paths';
import { set_manifest, set_read_implementation } from '__sveltekit/server';
import { set_private_env, set_public_env, set_safe_public_env } from '../../../node_modules/@sveltejs/kit/src/runtime/shared-server.js';

export const options = {
	app_template_contains_nonce: false,
	csp: {"mode":"auto","directives":{"upgrade-insecure-requests":false,"block-all-mixed-content":false},"reportOnly":{"upgrade-insecure-requests":false,"block-all-mixed-content":false}},
	csrf_check_origin: true,
	embedded: false,
	env_public_prefix: 'PUBLIC_',
	env_private_prefix: '',
	hash_routing: false,
	hooks: null, // added lazily, via `get_hooks`
	preload_strategy: "modulepreload",
	root,
	service_worker: false,
	service_worker_options: undefined,
	templates: {
		app: ({ head, body, assets, nonce, env }) => "<!doctype html>\r\n<html lang=\"en\">\r\n\t<head>\r\n\t\t<meta charset=\"utf-8\" />\r\n\t\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, viewport-fit=cover\" />\r\n\t\t\r\n\t\t<!-- Optimize resource loading -->\r\n\t\t<link rel=\"dns-prefetch\" href=\"//fonts.googleapis.com\" />\r\n\t\t<link rel=\"dns-prefetch\" href=\"//fonts.gstatic.com\" />\r\n\t\t\r\n\t\t<!-- Favicon with emoji for quick loading -->\r\n\t\t<link rel=\"icon\" href=\"data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>📝</text></svg>\" />\r\n\t\t\r\n\t\t<!-- Performance optimizations -->\r\n\t\t<meta name=\"theme-color\" content=\"#667eea\" />\r\n\t\t<meta name=\"color-scheme\" content=\"light dark\" />\r\n\t\t\r\n\t\t<!-- Preload critical resources -->\r\n\t\t<link rel=\"preload\" as=\"font\" type=\"font/woff2\" crossorigin href=\"https://fonts.gstatic.com/s/inter/v13/UcCO3FwrK3iLTeHuS_fvQtMwCp50KnMw2boKoduKmMEVuLyfAZ9hiA.woff2\" />\r\n\t\t\r\n\t\t<!-- SEO and social media -->\r\n\t\t<meta name=\"description\" content=\"TaskFlow - A beautiful, Notion-like task management application. Organize your tasks with style.\" />\r\n\t\t<meta name=\"keywords\" content=\"todo, task management, productivity, notion, organize\" />\r\n\t\t<meta name=\"author\" content=\"TaskFlow\" />\r\n\t\t\r\n\t\t<!-- Open Graph -->\r\n\t\t<meta property=\"og:type\" content=\"website\" />\r\n\t\t<meta property=\"og:title\" content=\"TaskFlow - Beautiful Task Management\" />\r\n\t\t<meta property=\"og:description\" content=\"Organize your tasks with a beautiful, Notion-like interface\" />\r\n\t\t<meta property=\"og:image\" content=\"/og-image.png\" />\r\n\t\t\r\n\t\t<!-- Twitter Card -->\r\n\t\t<meta name=\"twitter:card\" content=\"summary_large_image\" />\r\n\t\t<meta name=\"twitter:title\" content=\"TaskFlow - Beautiful Task Management\" />\r\n\t\t<meta name=\"twitter:description\" content=\"Organize your tasks with a beautiful, Notion-like interface\" />\r\n\t\t\r\n\t\t<!-- Critical CSS for above-the-fold content -->\r\n\t\t<style>\r\n\t\t\t/* Critical CSS for immediate rendering */\r\n\t\t\tbody {\r\n\t\t\t\tfont-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;\r\n\t\t\t\tline-height: 1.6;\r\n\t\t\t\tmargin: 0;\r\n\t\t\t\tpadding: 0;\r\n\t\t\t\tbackground: #f8fafc;\r\n\t\t\t\tcolor: #2d3748;\r\n\t\t\t\t-webkit-font-smoothing: antialiased;\r\n\t\t\t\t-moz-osx-font-smoothing: grayscale;\r\n\t\t\t}\r\n\t\t\t\r\n\t\t\t/* Prevent flash of unstyled content */\r\n\t\t\t.loading-fallback {\r\n\t\t\t\tposition: fixed;\r\n\t\t\t\ttop: 0;\r\n\t\t\t\tleft: 0;\r\n\t\t\t\twidth: 100%;\r\n\t\t\t\theight: 100%;\r\n\t\t\t\tbackground: linear-gradient(135deg, #667eea 0%, #764ba2 100%);\r\n\t\t\t\tdisplay: flex;\r\n\t\t\t\talign-items: center;\r\n\t\t\t\tjustify-content: center;\r\n\t\t\t\tcolor: white;\r\n\t\t\t\tfont-size: 1.2rem;\r\n\t\t\t\tfont-weight: 500;\r\n\t\t\t\tz-index: 9999;\r\n\t\t\t}\r\n\t\t\t\r\n\t\t\t.loading-fallback::after {\r\n\t\t\t\tcontent: '📝';\r\n\t\t\t\tfont-size: 3rem;\r\n\t\t\t\tmargin-bottom: 1rem;\r\n\t\t\t\tdisplay: block;\r\n\t\t\t}\r\n\t\t</style>\r\n\t\t\r\n\t\t" + head + "\r\n\t</head>\r\n\t<body data-sveltekit-preload-data=\"hover\">\r\n\t\t<!-- Fallback loading screen for immediate display -->\r\n\t\t<div class=\"loading-fallback\">\r\n\t\t\t<div>\r\n\t\t\t\t<div style=\"font-size: 3rem; margin-bottom: 1rem;\">📝</div>\r\n\t\t\t\tLoading TaskFlow...\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t\t\r\n\t\t<div style=\"display: contents\">" + body + "</div>\r\n\t\t\r\n\t\t<!-- Remove loading fallback after app loads -->\r\n\t\t<script>\r\n\t\t\twindow.addEventListener('load', function() {\r\n\t\t\t\tconst fallback = document.querySelector('.loading-fallback');\r\n\t\t\t\tif (fallback) {\r\n\t\t\t\t\tfallback.style.opacity = '0';\r\n\t\t\t\t\tfallback.style.transition = 'opacity 0.3s ease';\r\n\t\t\t\t\tsetTimeout(() => fallback.remove(), 300);\r\n\t\t\t\t}\r\n\t\t\t});\r\n\t\t\t\r\n\t\t\t// Handle offline state\r\n\t\t\twindow.addEventListener('online', () => {\r\n\t\t\t\tdocument.body.classList.remove('offline');\r\n\t\t\t});\r\n\t\t\t\r\n\t\t\twindow.addEventListener('offline', () => {\r\n\t\t\t\tdocument.body.classList.add('offline');\r\n\t\t\t});\r\n\t\t\t\r\n\t\t\t// Performance monitoring\r\n\t\t\tif ('PerformanceObserver' in window) {\r\n\t\t\t\t// Monitor Largest Contentful Paint\r\n\t\t\t\tconst lcpObserver = new PerformanceObserver((entryList) => {\r\n\t\t\t\t\tconst entries = entryList.getEntries();\r\n\t\t\t\t\tconst lastEntry = entries[entries.length - 1];\r\n\t\t\t\t\tconsole.log('LCP:', lastEntry.startTime);\r\n\t\t\t\t});\r\n\t\t\t\tlcpObserver.observe({ entryTypes: ['largest-contentful-paint'] });\r\n\t\t\t\t\r\n\t\t\t\t// Monitor First Input Delay\r\n\t\t\t\tconst fidObserver = new PerformanceObserver((entryList) => {\r\n\t\t\t\t\tconst entries = entryList.getEntries();\r\n\t\t\t\t\tentries.forEach((entry) => {\r\n\t\t\t\t\t\tconsole.log('FID:', entry.processingStart - entry.startTime);\r\n\t\t\t\t\t});\r\n\t\t\t\t});\r\n\t\t\t\tfidObserver.observe({ entryTypes: ['first-input'] });\r\n\t\t\t}\r\n\t\t</script>\r\n\t</body>\r\n</html>\r\n",
		error: ({ status, message }) => "<!doctype html>\n<html lang=\"en\">\n\t<head>\n\t\t<meta charset=\"utf-8\" />\n\t\t<title>" + message + "</title>\n\n\t\t<style>\n\t\t\tbody {\n\t\t\t\t--bg: white;\n\t\t\t\t--fg: #222;\n\t\t\t\t--divider: #ccc;\n\t\t\t\tbackground: var(--bg);\n\t\t\t\tcolor: var(--fg);\n\t\t\t\tfont-family:\n\t\t\t\t\tsystem-ui,\n\t\t\t\t\t-apple-system,\n\t\t\t\t\tBlinkMacSystemFont,\n\t\t\t\t\t'Segoe UI',\n\t\t\t\t\tRoboto,\n\t\t\t\t\tOxygen,\n\t\t\t\t\tUbuntu,\n\t\t\t\t\tCantarell,\n\t\t\t\t\t'Open Sans',\n\t\t\t\t\t'Helvetica Neue',\n\t\t\t\t\tsans-serif;\n\t\t\t\tdisplay: flex;\n\t\t\t\talign-items: center;\n\t\t\t\tjustify-content: center;\n\t\t\t\theight: 100vh;\n\t\t\t\tmargin: 0;\n\t\t\t}\n\n\t\t\t.error {\n\t\t\t\tdisplay: flex;\n\t\t\t\talign-items: center;\n\t\t\t\tmax-width: 32rem;\n\t\t\t\tmargin: 0 1rem;\n\t\t\t}\n\n\t\t\t.status {\n\t\t\t\tfont-weight: 200;\n\t\t\t\tfont-size: 3rem;\n\t\t\t\tline-height: 1;\n\t\t\t\tposition: relative;\n\t\t\t\ttop: -0.05rem;\n\t\t\t}\n\n\t\t\t.message {\n\t\t\t\tborder-left: 1px solid var(--divider);\n\t\t\t\tpadding: 0 0 0 1rem;\n\t\t\t\tmargin: 0 0 0 1rem;\n\t\t\t\tmin-height: 2.5rem;\n\t\t\t\tdisplay: flex;\n\t\t\t\talign-items: center;\n\t\t\t}\n\n\t\t\t.message h1 {\n\t\t\t\tfont-weight: 400;\n\t\t\t\tfont-size: 1em;\n\t\t\t\tmargin: 0;\n\t\t\t}\n\n\t\t\t@media (prefers-color-scheme: dark) {\n\t\t\t\tbody {\n\t\t\t\t\t--bg: #222;\n\t\t\t\t\t--fg: #ddd;\n\t\t\t\t\t--divider: #666;\n\t\t\t\t}\n\t\t\t}\n\t\t</style>\n\t</head>\n\t<body>\n\t\t<div class=\"error\">\n\t\t\t<span class=\"status\">" + status + "</span>\n\t\t\t<div class=\"message\">\n\t\t\t\t<h1>" + message + "</h1>\n\t\t\t</div>\n\t\t</div>\n\t</body>\n</html>\n"
	},
	version_hash: "bddkc8"
};

export async function get_hooks() {
	let handle;
	let handleFetch;
	let handleError;
	let handleValidationError;
	let init;
	

	let reroute;
	let transport;
	

	return {
		handle,
		handleFetch,
		handleError,
		handleValidationError,
		init,
		reroute,
		transport
	};
}

export { set_assets, set_building, set_manifest, set_prerendering, set_private_env, set_public_env, set_read_implementation, set_safe_public_env };
