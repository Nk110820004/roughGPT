
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	export interface AppTypes {
		RouteId(): "/" | "/create-index" | "/delete-note" | "/insert-note" | "/new" | "/new/search" | "/search-note" | "/workspace";
		RouteParams(): {
			
		};
		LayoutParams(): {
			"/": Record<string, never>;
			"/create-index": Record<string, never>;
			"/delete-note": Record<string, never>;
			"/insert-note": Record<string, never>;
			"/new": Record<string, never>;
			"/new/search": Record<string, never>;
			"/search-note": Record<string, never>;
			"/workspace": Record<string, never>
		};
		Pathname(): "/" | "/create-index" | "/delete-note" | "/insert-note" | "/new" | "/new/search" | "/search-note" | "/workspace";
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): "/add.svg" | "/board.svg" | "/category.svg" | "/check.svg" | "/delete.svg" | "/disconnect.svg" | "/edit.svg" | "/favicon.png" | "/list.svg" | "/logout.svg" | "/manifest.json" | "/moon.svg" | "/plug.svg" | "/search.svg" | "/socket.svg" | "/sun.svg" | "/sw.js";
	}
}